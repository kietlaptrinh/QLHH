/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CacClaasCuaKiet;

/**
 *
 * @author DUONG TUAN KIET
 */
public class Grade {
    private int id;
    private KhoHoaQua khq;
    private double loaiMot, loaiHai, loaiBa;

    public Grade() {
    }

    public Grade(int id, KhoHoaQua khq, double loaiMot, double loaiHai, double loaiBa) {
        this.id = id;
        this.khq = khq;
        this.loaiMot = loaiMot;
        this.loaiHai = loaiHai;
        this.loaiBa = loaiBa;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public KhoHoaQua getKhq() {
        return khq;
    }

    public void setKhq(KhoHoaQua khq) {
        this.khq = khq;
    }

    public double getLoaiMot() {
        return loaiMot;
    }

    public void setLoaiMot(double loaiMot) {
        this.loaiMot = loaiMot;
    }

    public double getLoaiHai() {
        return loaiHai;
    }

    public void setLoaiHai(double loaiHai) {
        this.loaiHai = loaiHai;
    }

    public double getLoaiBa() {
        return loaiBa;
    }

    public void setLoaiBa(double loaiBa) {
        this.loaiBa = loaiBa;
    }
    public double getTONG(){
    return getLoaiMot()+getLoaiHai()+getLoaiBa();
            }
    public String getTrangThaiKho(){
    String ttk = "";
    double tong = getTONG();
    if(tong>1000){
    ttk = "QUA TAI";
    }else if(tong >=900){
    ttk = "DAY KHO";
    }else if(tong >=600){
    ttk = "KHO CHUA DAY";
    }else{
    ttk = "TRONG KHO";
    }
    return ttk;
    }
    }

