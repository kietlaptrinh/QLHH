/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CacClaasCuaKiet;

import java.util.ArrayList;

/**
 *
 * @author DUONG TUAN KIET
 */
public class KhoHoaQuaDAO {
  public static  ArrayList<KhoHoaQua> ls = new ArrayList<>();

    public KhoHoaQuaDAO() {
        ls.add(new KhoHoaQua("QK01", "DAU HA LAN"));
         ls.add(new KhoHoaQua("QK02", "QUA NGO"));
          ls.add(new KhoHoaQua("QT01", "MIT"));
           ls.add(new KhoHoaQua("QT02", "NHO"));
            ls.add(new KhoHoaQua("QT03", "CA CHUA"));
    }
  
    public int add(KhoHoaQua khq){
    ls.add(khq);
    return 1;}
    public ArrayList<KhoHoaQua> getAllKhoHoaQua(){
        return ls;
    }
    public int delKhoHoaQuaByID(String ma){
    for(KhoHoaQua khq:ls){
        if(khq.getMakhO().equalsIgnoreCase(ma))
            ls.remove(khq);
        return 1;
    }
    
    return -1;
    }
    public KhoHoaQua getKhoHoaQuaByID(String id){
    for(KhoHoaQua khq:ls){
    if(khq.getMakhO().equalsIgnoreCase(id)){
    return khq;
    }
    }
    return null;
    }
    public int updateKhoHoaQuaByID(KhoHoaQua khqNew){
    for(KhoHoaQua khq:ls){
    if(khq.getMakhO().equalsIgnoreCase(khqNew.getMakhO())){
    khq.setVitrI(khqNew.getVitrI());
    khq.setChatluonG(khqNew.isChatluonG());
    khq.setHinhanH(khqNew.getHinhanH());
    khq.setNgaY(khqNew.getNgaY());
    khq.setLoaI(khqNew.getLoaI());
    return 1;}
}return -1;
}}
