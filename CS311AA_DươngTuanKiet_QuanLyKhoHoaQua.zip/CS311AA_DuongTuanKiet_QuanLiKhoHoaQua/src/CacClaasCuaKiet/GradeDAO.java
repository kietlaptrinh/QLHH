/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CacClaasCuaKiet;

import java.awt.List;
import java.util.ArrayList;

/**
 *
 * @author DUONG TUAN KIET
 */
public class GradeDAO {
    ArrayList<Grade> ls = new ArrayList<>();
    public int add(Grade d){
    ls.add(d);
    return 1;
    }
    public ArrayList<Grade> getALLGrade(){
    return ls;
    }
    public Grade getOneGradeBymakhO(String makhq){
    for(Grade d:ls){
    if(d.getKhq().getMakhO().equalsIgnoreCase(makhq))
        return d;
    }
    return null;
    }
    public int updateGrade(Grade dNew){
    for(Grade d:ls){
    if(d.getKhq().getMakhO().equalsIgnoreCase(dNew.getKhq().getMakhO()))
        
        d.setLoaiMot(dNew.getLoaiMot());
        d.setLoaiHai(dNew.getLoaiHai());
        d.setLoaiBa(dNew.getLoaiBa());
        
        return 1;
    }
    return -1;
    }
    public int delGrade(String makhq){
    Grade d = getOneGradeBymakhO(makhq);
    if(d!=null){
    ls.remove(d);
    return 1;
    }return -1;
    }
    public Grade getAtPosition(int pos){
    return ls.get(pos);
    }
}
