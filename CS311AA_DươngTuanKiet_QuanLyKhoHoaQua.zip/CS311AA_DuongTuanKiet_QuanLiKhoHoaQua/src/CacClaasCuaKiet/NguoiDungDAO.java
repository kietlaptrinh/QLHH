/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CacClaasCuaKiet;

import java.awt.List;
import java.util.ArrayList;

/**
 *
 * @author DUONG TUAN KIET
 */
public class NguoiDungDAO {
    ArrayList<NguoiDung> ls = new ArrayList<>();

    public NguoiDungDAO() {
        ls.add(new NguoiDung("admin", "12345", true));
        ls.add(new NguoiDung("cam", "123", true));
        ls.add(new NguoiDung("nho", "12345", true));
        ls.add(new NguoiDung("admin1", "12345", true));
        ls.add(new NguoiDung("admin2", "12345", true));
    }
    public boolean checkDangNhap(String username, String password){
        for(NguoiDung n:ls){
            if(n.getUsername().equals(username)&&n.getPassword().equals(password)){
                return true;
            }}
            return false;
        
    }
            
}
