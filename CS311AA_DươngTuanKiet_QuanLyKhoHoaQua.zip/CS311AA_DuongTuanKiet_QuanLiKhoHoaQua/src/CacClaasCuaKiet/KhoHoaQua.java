/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CacClaasCuaKiet;

import java.util.Date;

/**
 *
 * @author DUONG TUAN KIET
 */
public class KhoHoaQua {
    private String makhO;
    private String loaI;
    private String ngaY;
    private boolean chatluonG;
    private String vitrI;
    private String hinhanH;

    public KhoHoaQua() {
    }

    public KhoHoaQua(String makhO, String loaI) {
        this.makhO = makhO;
        this.loaI = loaI;
    }
    
    public KhoHoaQua(String makhO, String loaI, String ngaY, boolean chatluonG, String vitrI, String hinhanH) {
        this.makhO = makhO;
        this.loaI = loaI;
        this.ngaY = ngaY;
        this.chatluonG = chatluonG;
        this.vitrI = vitrI;
        this.hinhanH = hinhanH;
    }

    public String getMakhO() {
        return makhO;
    }

    public void setMakhO(String makhO) {
        this.makhO = makhO;
    }

    public String getLoaI() {
        return loaI;
    }

    public void setLoaI(String loaI) {
        this.loaI = loaI;
    }

    public String getNgaY() {
        return ngaY;
    }

    public void setNgaY(String ngaY) {
        this.ngaY = ngaY;
    }

    public boolean isChatluonG() {
        return chatluonG;
    }

    public void setChatluonG(boolean chatluonG) {
        this.chatluonG = chatluonG;
    }

    public String getVitrI() {
        return vitrI;
    }

    public void setVitrI(String vitrI) {
        this.vitrI = vitrI;
    }

    public String getHinhanH() {
        return hinhanH;
    }

    public void setHinhanH(String hinhanH) {
        this.hinhanH = hinhanH;
    }
    
}
